<%@ page import="java.util.*, model.Event" %>
<%@ include file="nav.jsp" %>
<html>
<head>
  <title>Emma's Event Management - Home</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

  <form action="EventServlet" method="get">
  <h3>Search Events</h3>
    <input type="hidden" name="action" value="search" />
    <label>Keyword: <input type="text" name="keyword" placeholder="Event name, Category, Location" /></label>
    <label>From Date: <input type="date" name="fromDate" /></label>
    <label>To Date: <input type="date" name="toDate" /></label>
    <input type="submit" value="Search" />
  </form>
    <br>
    <br>
  <h1>Event Listings</h1>
  <table border="1" cellpadding="8">
    <tr>
      <th>Event Name</th>
      <th>Date</th>
      <th>Location</th>
      <th>Description</th>
      <th>Type</th>
      <th>Actions</th>
    </tr>
    <%
      List<Event> listEvent = (List<Event>) request.getAttribute("listEvent");
      if(listEvent != null) {
          for(Event event : listEvent) {
    %>
    <tr>
      <td><%= event.getEventName() %></td>
      <td><%= event.getEventDate() %></td>
      <td><%= event.getLocation() %></td>
      <td><%= event.getDescription() %></td>
      <td><%= event.getEventType() %></td>
      <td>
        <a href="EventServlet?action=edit&id=<%= event.getId() %>">Edit</a> |
        <a href="EventServlet?action=delete&id=<%= event.getId() %>" onclick="return confirm('Are you sure?');">Delete</a> |
        <a href="rsvpEvent.jsp?eventId=<%= event.getId() %>">RSVP</a>
      </td>
    </tr>
    <%
          }
      }
    %>
  </table>

</body>
</html>
