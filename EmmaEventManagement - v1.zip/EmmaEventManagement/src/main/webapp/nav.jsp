<nav>
<h1 style="color: #fff">Emma Event Management System</h1>
  <ul style="list-style: none; display: flex; gap: 15px;">
    <li><a href="EventServlet">Home</a></li>
    <li><a href="addEvent.jsp">Add New Event</a></li>
  </ul>
  <hr>
</nav>
