package model;

import java.sql.Date;

public class Event {
    private int id;
    private String eventName;
    private Date eventDate;
    private String location;
    private String description;
    private String eventType;

    public Event() {}

    public Event(String eventName, Date eventDate, String location, String description, String eventType) {
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.location = location;
        this.description = description;
        this.eventType = eventType;
    }

    public Event(int id, String eventName, Date eventDate, String location, String description, String eventType) {
        this.id = id;
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.location = location;
        this.description = description;
        this.eventType = eventType;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getEventName() { return eventName; }
    public void setEventName(String eventName) { this.eventName = eventName; }

    public Date getEventDate() { return eventDate; }
    public void setEventDate(Date eventDate) { this.eventDate = eventDate; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }
}
