package dao;

import model.Event;
import connection.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventDAO {
    private static Connection connection = DBConnection.getConnection();

    public static List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        try {
            String sql = "SELECT * FROM events";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Event event = new Event();
                event.setId(rs.getInt("id"));
                event.setEventName(rs.getString("event_name"));
                event.setEventDate(rs.getDate("event_date"));
                event.setLocation(rs.getString("location"));
                event.setDescription(rs.getString("description"));
                event.setEventType(rs.getString("event_type"));
                events.add(event);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return events;
    }


    public static List<Event> searchEvents(String keyword, String fromDateStr, String toDateStr) {
        List<Event> events = new ArrayList<>();
        try {
            StringBuilder sql = new StringBuilder("SELECT * FROM events WHERE 1=1 ");
            List<Object> params = new ArrayList<>();

            if (keyword != null && !keyword.trim().isEmpty()) {
                sql.append(" AND (event_name LIKE ? OR location LIKE ? OR event_type LIKE ?) ");
                String searchKeyword = "%" + keyword.trim() + "%";
                params.add(searchKeyword);
                params.add(searchKeyword);
                params.add(searchKeyword);
            }

            if (fromDateStr != null && !fromDateStr.trim().isEmpty()) {
                sql.append(" AND event_date >= ? ");
                params.add(Date.valueOf(fromDateStr.trim()));
            }

            if (toDateStr != null && !toDateStr.trim().isEmpty()) {
                sql.append(" AND event_date <= ? ");
                params.add(Date.valueOf(toDateStr.trim()));
            }

            PreparedStatement ps = connection.prepareStatement(sql.toString());
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Event event = new Event();
                event.setId(rs.getInt("id"));
                event.setEventName(rs.getString("event_name"));
                event.setEventDate(rs.getDate("event_date"));
                event.setLocation(rs.getString("location"));
                event.setDescription(rs.getString("description"));
                event.setEventType(rs.getString("event_type"));
                events.add(event);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return events;
    }

}
